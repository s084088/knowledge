﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LiteEntity;
using LiteEntity.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Util;

namespace KnowledgeGraph.Controllers
{
    public class GraphController : Controller
    {
        private readonly LiteDB liteDB = new LiteDB();

        public IActionResult Index()
        {
            return View();
        }

        public ActionResult GetGraph()
        {
            List<KP> kPs = liteDB.Set<KP>().ToList();
            List<KPR> kPRs = liteDB.Set<KPR>().ToList();

            var nodes = kPs.Select(l => new
            {
                id = l.ID,
                name = l.Name,
                symbolSize = (9 - l.Type) * (9 - l.Type) / 4D,
                category = l.Importance - 1,
                label = new
                {
                    show = true,
                    fontSize =12- l.Type
                },
            });

            var links = kPRs.Select(l => new
            {
                id = l.Text,
                source = l.OriginID,
                target = l.TargetID,
                name = l.Text,
            });

            var categories = new string[] { "数与代数", "图形与几何", "解决问题", "统计与概率" }.Select(l => new
            {
                name = l,
            });

            ApiPakcage apiPakcage = new ApiPakcage { Result = new { nodes, links, categories } };


            return Content(apiPakcage.ToJson());
        }
    }
}
